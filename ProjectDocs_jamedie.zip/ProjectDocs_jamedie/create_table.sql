DROP TABLE LeaseAgreement;
DROP TABLE RentalProperty;
DROP TABLE PropertyOwner;
DROP TABLE Supervisor;
DROP TABLE Branch;
DROP TABLE Employee;


CREATE TABLE Employee(
	EmployeeID			VARCHAR(10) PRIMARY KEY,
	Name				VARCHAR(30),
	Phone				INTEGER,
	StartDate			DATE,
	JobDesignation		VARCHAR(30) CHECK (JobDesignation IN ('Manager','Supervisor','Staff')),
	BranchNumber		VARCHAR(10)
);

/***
CREATE TABLE Manager(
	employee_id CHAR(10) PRIMARY KEY,
	FOREIGN KEY (employee_id) REFERENCES Employee(EmployeeID) ON DELETE CASCADE
);
**/

CREATE TABLE Branch(
	BranchNumber		VARCHAR(10) PRIMARY KEY,
	Phone				INTEGER,
	StreetAddress		VARCHAR(50),
	City				VARCHAR(50),
	Zip					INTEGER CHECK (Zip >= 10000 AND Zip < 100000),
	ManagerID 			VARCHAR(10),
	SupervisorID		VARCHAR(10),
	FOREIGN KEY (ManagerID) REFERENCES Employee(EmployeeID) ON DELETE CASCADE,
	FOREIGN KEY (SupervisorID) REFERENCES Employee(EmployeeID)
);

CREATE TABLE Supervisor(
	SupervisorID CHAR(10) PRIMARY KEY,
	ManagerID    CHAR(10),
	FOREIGN KEY (ManagerID) REFERENCES Employee(EmployeeID) 
);

CREATE TABLE PropertyOwner(
	PropertyOwnerID		VARCHAR(10) PRIMARY KEY,
	Name 				VARCHAR(30),
	StreetAddress		VARCHAR(50),
	City				VARCHAR(50),
	Zip					INTEGER,
	Phone				INTEGER
);

CREATE TABLE RentalProperty(
	PropertyNumber		VARCHAR(10) PRIMARY KEY,
	PropertyOwnerID		VARCHAR(10),
	Supervisor_id       VARCHAR(10),
	StreetAddress		VARCHAR(50),
	City				VARCHAR(50),
	Zip					INTEGER CHECK (Zip >= 10000 AND Zip < 100000),
	NumRooms	    	INTEGER,
	MRent   			NUMBER(12,2),
	Status				VARCHAR(20)  CHECK (Status IN ('Available','Leased')),
	AvailStartDate		DATE,
	FOREIGN KEY (Supervisor_id) REFERENCES Employee(EmployeeID),
	FOREIGN KEY (PropertyOwnerID) REFERENCES PropertyOwner(PropertyOwnerID)
);

CREATE TABLE LeaseAgreement(
	LeaseNumber			VARCHAR(10) PRIMARY KEY,
	PropertyNumber		VARCHAR(10),
	RenterNumber		VARCHAR(10),
	RenterName			VARCHAR(30),
	HomePhone			INTEGER ,
	WorkPhone			INTEGER, 
	StartDate 			DATE,
	EndDate 			DATE, 
	DepositAmount		NUMBER(7,2),
	RentAmount			NUMBER(7,2),
	SuperName			VARCHAR(30),
	CONSTRAINT LeaseLength CHECK (MONTHS_BETWEEN(EndDate, StartDate) >= 6 AND MONTHS_BETWEEN(StartDate, EndDate) <= 12),
	FOREIGN KEY (PropertyNumber) REFERENCES RentalProperty(PropertyNumber)
);

CREATE TABLE RENTER(
	RenterNumber VARCHAR(10) PRIMARY KEY,
	PropertyNumber		VARCHAR(10),
	RenterName			VARCHAR(30),
	HomePhone			INTEGER ,
	WorkPhone			INTEGER 
);