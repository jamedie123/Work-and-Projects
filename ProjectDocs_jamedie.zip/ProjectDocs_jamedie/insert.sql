INSERT INTO Employee VALUES('emp1', 'tom', '4081238423', TO_DATE('01/01/2010', 'MM/DD/YYYY'), 'Manager', 'branch1' );
INSERT INTO Employee VALUES('emp2', 'dan', '4081234567', TO_DATE('01/01/1990', 'MM/DD/YYYY'),'Supervisor','branch1');
INSERT INTO Employee VALUES('emp3', 'william', '5107123333', TO_DATE('01/01/2001', 'MM/DD/YYYY'),'Supervisor','branch3');
INSERT INTO Employee VALUES('emp4', 'jake', '4151234567', TO_DATE('01/01/2010', 'MM/DD/YYYY'),'Supervisor','branch3');
INSERT INTO Employee VALUES('emp5', 'marl', '4085552346', TO_DATE('01/01/2001', 'MM/DD/YYYY'), 'Supervisor','branch2');
INSERT INTO Employee VALUES('emp6', 'paul', '4151234567', TO_DATE('01/01/1990', 'MM/DD/YYYY'),'Manager','branch2');
INSERT INTO Employee VALUES('emp7', 'max', '4151234567', TO_DATE('01/01/1990', 'MM/DD/YYYY'),'Staff','branch1');
INSERT INTO Employee VALUES('emp8', 'carl', '4151234567', TO_DATE('01/01/1990', 'MM/DD/YYYY'),'Staff','branch2');


INSERT INTO Branch VALUES('branch1', '4085552346', '1223 Mission Blvd', 'Santa Clara', '95050', 'emp1','emp2');
INSERT INTO Branch VALUES('branch2', '4085551212', '4543 El Camino Blvd', 'San Jose', '95123', 'emp6','emp5');
INSERT INTO Branch VALUES('branch3', '4085551212', '4513 Saratoga Ave', 'San Jose', '95117', 'emp1','emp3');


INSERT INTO PropertyOwner VALUES('owner1', 'Patricia','1234 Market st', 'San Jose', 95117, 4081238423);
INSERT INTO PropertyOwner VALUES('owner2', 'Melissa', '123 Alameda st', 'Campbell', 95145, 4081231111);

INSERT INTO RentalProperty VALUES('Property1', 'owner1','emp2', '111 Market St','San Jose', 95117, 5, 4000, 'Available', TO_DATE('06/01/2018', 'MM/DD/YYYY'));
INSERT INTO RentalProperty VALUES('Property2', 'owner2','emp2', '342 Bascom Ave', 'Fremont', 94536, 3, 3000, 'Available', TO_DATE('03/01/2018', 'MM/DD/YYYY'));
INSERT INTO RentalProperty VALUES('Property3', 'owner2','emp3', '456 Newhall Ave', 'San Jose', 95125, 3, 8000, 'Available', TO_DATE('05/21/2018', 'MM/DD/YYYY'));
INSERT INTO RentalProperty VALUES('Property4', 'owner1','emp4', '76 King Road', 'San Jose', 95117, 3, 2000, 'Available', TO_DATE('06/01/2018', 'MM/DD/YYYY'));
INSERT INTO RentalProperty VALUES('Property5', 'owner2','emp4', '168 Park Ave', 'San Jose', 95127, 3, 4000, 'Available', TO_DATE('05/01/2018', 'MM/DD/YYYY'));
INSERT INTO RentalProperty VALUES('Property6', 'owner1','emp5', '9045 Jackson Street', 'Fremont', 94538, 3, 4000, 'Available', TO_DATE('09/01/2018', 'MM/DD/YYYY'));


INSERT INTO LeaseAgreement VALUES('Lease3', 'Property3', 'renter3', 'Daniel', 4084568423, 4081238423, TO_DATE('06/11/2018', 'MM/DD/YYYY'), TO_DATE('04/01/2019', 'MM/DD/YYYY'), 500, 8000,'william'); 
INSERT INTO LeaseAgreement VALUES('Lease1', 'Property4', 'renter3', 'Daniel', 4084568423, 4081238423, TO_DATE('01/01/2018', 'MM/DD/YYYY'), TO_DATE('07/11/2018', 'MM/DD/YYYY'), 500, 8000,'william'); 




