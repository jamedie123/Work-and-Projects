<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<title>Happy Renter's Rental Management</title>
	<link rel="stylesheet" type="text/css" href="project.css">
</head>
<body>
	<header>
		<h1>Happy Renter's Rental Management</h1>
	</header>
		<nav>
           <ul>
 				<li><a id="home" class="home" href="http://students.engr.scu.edu/~jamedie/project/">Home</a></li
				><li><a id="lease" href="enter_lease.html">Create a Lease Agreement</a></li
				><li><a id="properties" href="properties.php">Properties Report</a></li
				><li><a id="supervisors" class="current" href="supervisors.php">Supervisors Report</a></li
				><li><a id="renters" href="renters.php">Renters Report</a></li
				><li><a id="misc" href="misc.php">Miscellenous</a></li
          </ul>
        </nav>
	<div class="below-nav"></div>
	<main>

<?php

supervisors();

// Generate tables for supervisors
function supervisors() {
	$conn=oci_connect( 'jamedie', 'Liveoak123', '//dbserver.engr.scu.edu/db11g' );
	if(!$conn) {
		print "<br> connection failed:";
		exit;	}

	$query = oci_parse($conn,"select E.NAME, PROPERTYNUMBER, STREETADDRESS, CITY, ZIP, STATUS from RentalProperty, employee E
where SUPERVISOR_ID=E.EMPLOYEEID");
	

	echo '<h3 id="query">List of Supervisors & Properties w/ Status </h3>';
	oci_execute($query);
	echo "\n<table>\n";
	echo "\t<tr><th>Suporvisor</th><th>Property</th><th>Address</th><th>City</th><th>Zip</th><th>Status</th></tr>\n\t";
	while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "<tr>\n";
	
		echo "\t\t<td>$row[0]</td>\n";
		echo "\t\t<td>$row[1]</td>\n";
		echo "\t\t<td>$row[2]</td>\n";
		echo "\t\t<td>$row[3]</td>\n";
		echo "\t\t<td>$row[4]</td>\n";
		echo "\t\t<td>$row[5]</td>\n";
		echo "\t</tr>";
	}
	echo "\n</table>\n";

	OCILogoff($conn);
}


?>
<!-- end PHP script -->
	</main>
</body>
</html>
