<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<title>Happy Renter's Rental Management</title>
	<link rel="stylesheet" type="text/css" href="project.css">
</head>
<body>
	<header>
		<h1>Happy Renter's Rental Management</h1>
	</header>
		<nav>
           <ul>
 				<li><a id="home" class="home" href="http://students.engr.scu.edu/~jamedie/project/">Home</a></li
				><li><a id="lease" href="enter_lease.html">Create a Lease Agreement</a></li
				><li><a id="properties" href="properties.php">Properties Report</a></li
				><li><a id="supervisors" href="supervisors.php">Supervisors Report</a></li
				><li><a id="renters" href="renters.php">Renters Report</a></li
				><li><a id="misc" class="current" href="misc.php">Miscellenous</a></li
          </ul>
        </nav>
	<div class="below-nav"></div>
	<main>
	
   <!-- Complete the URL -->
   <a href='http://students.engr.scu.edu/~jamedie/project/misc.php?employees=true'>Show the Employee Table</a>
    <br><br>
   <a href='http://students.engr.scu.edu/~jamedie/project/ProjectReport.sql'>Show SQL Code for Transactions 1-10</a>
   <br><br>
   <a href='http://students.engr.scu.edu/~jamedie/project/ProjectOutput.lst'>Show SQL Result Output</a>
	 <br><br>

<?php

if (isset($_GET['show'])) {
 
}
elseif (isset($_GET['employees'])) {
    employees();
} elseif (isset($_GET['employeedetails'])){
		EmployeeDetails();
}


function howManyBooks(){
	//connect to your database. Type in your username, password and the DB path
	$conn=oci_connect("jamedie", "Liveoak123", "//dbserver.engr.scu.edu/db11g");
	if(!$conn) {
	     print "<br> connection failed:";
        exit;
	}
	
//	$query = oci_parse($conn, "SELECT bookcount from Dual");
	
	// Execute the query
	oci_execute($query);
	if (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "You have read <font color='blue;font-size:20px'> $row[0] </font></br>";
	}
}


// Generate employees
function employees() {
	$conn=oci_connect( 'jamedie', 'Liveoak123', '//dbserver.engr.scu.edu/db11g' );
	if(!$conn) {
		print "<br> connection failed:";
		exit;	}

	$query = oci_parse(
		$conn,
		"SELECT  * from EMPLOYEE");
		
	/*	"SELECT B.BRANCHNUMBER, P.PROPERTYNUMBER, P.PropertyOwnerID, E.NAME As Manager, P.STREETADDRESS, P.CITY, P.ZIP, P.numrooms, P.mrent, P.status
         FROM RentalProperty P, BRANCH B, EMPLOYEE E where B.MANAGERID='emp1' and P.supervisor_id= B.SUPERVISORID and B.MANAGERID=E.EMPLOYEEID");
	    select E.NAME, PROPERTYNUMBER, STREETADDRESS, CITY, ZIP, STATUS from RentalProperty, employee E
where SUPERVISOR_ID=E.EMPLOYEEID");  */
	
	echo '<h3 id="query">Employee List</h3>';
	oci_execute($query);
	echo "\n<table>\n";
	echo "\t<tr><th>Empl ID</th><th>Name</th><th>Phone</th><th>Start Date</th><th>Position</th><th>Branch</th></tr>\n\t";
	while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "<tr>\n";
		
		echo "\t\t<td>$row[0]</td>\n";
		echo "\t\t<td>$row[1]</td>\n";
		echo "\t\t<td>$row[2]</td>\n";
		echo "\t\t<td>$row[3]</td>\n";
		echo "\t\t<td>$row[4]</td>\n";
		echo "\t\t<td>$row[5]</td>\n";
		echo "\t</tr>";
	}
	echo "\n</table>\n";   


	OCILogoff($conn);
}


?>
<!-- end PHP script -->
	</main>
</body>
</html>
