<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<title>Happy Renter's Rental Management</title>
	<link rel="stylesheet" type="text/css" href="project.css">
</head>
<body>
	<header>
		<h1>Happy Renter's Rental Management</h1>
	</header>
	<nav>
		<ul>
 			<li><a id="home" class="home" href="http://students.engr.scu.edu/~jamedie/project/">Home</a></li
			><li><a id="lease" href="enter_lease.html">Create a Lease Agreement</a></li
			><li><a id="properties" class="current" href="properties.php">Properties Report</a></li
			><li><a id="supervisors" href="supervisors.php">Supervisors Report</a></li
			><li><a id="renters" href="renters.php">Renters Report</a></li
			><li><a id="misc" href="misc.php">Miscellenous</a></li
         </ul>
	</nav>
	<div class="below-nav"></div>
	<main>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">        
	
	 <label for="BranchNumber">Select:</label>
	 <select name="BranchNumber" id="BranchNumber">
		   <option value="Branch1">Branch1</option>
		   <option value="Branch2">Branch2</option>
		   <option value="Branch3">Branch3</option>
	  </select>   
	  <input type="submit">
    </form>
	
	
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    # collect input data
# collect input data
	 $branch = $_POST['BranchNumber'];
	// echo $branch;
}
else{
   $branch = 'Branch1';
}	
properties($branch);

function properties($branch) {
	$conn=oci_connect( 'jamedie', 'Liveoak123', '//dbserver.engr.scu.edu/db11g' );
	if(!$conn) {
		print "<br> connection failed:";
		exit;
	}

	$query = oci_parse(
		$conn,
		"SELECT  B.BRANCHNUMBER, P.PROPERTYNUMBER, P.PropertyOwnerID, E.NAME As Manager, P.STREETADDRESS, P.CITY, P.ZIP, P.numrooms, P.mrent, P.status
         FROM RentalProperty P, BRANCH B, EMPLOYEE E where upper(B.BranchNumber)=upper(:bv) and B.MANAGERID=E.EMPLOYEEID and P.supervisor_id= B.SUPERVISORID and B.MANAGERID=E.EMPLOYEEID");
		 
	//	 "SELECT  B.BRANCHNUMBER, P.PROPERTYNUMBER, P.PropertyOwnerID, E.NAME As Manager, P.STREETADDRESS, P.CITY, P.ZIP, P.numrooms, P.mrent, P.status
    //     FROM RentalProperty P, BRANCH B, EMPLOYEE E where B.MANAGERID='emp1' and P.supervisor_id= B.SUPERVISORID and B.MANAGERID=E.EMPLOYEEID");
	
		//	 Parse the SQL query
	//$query = oci_parse($conn, "SELECT salary FROM AlphacoEmp where name= :bv");

	oci_bind_by_name($query,':bv',$branch);
	
	echo '<h4 id="query">Properties & Manager Info For a Branch</h4>';
	oci_execute($query);
	echo "\n<table>\n";
	echo "\t<tr><th>Branch1</th><th>Property</th><th>Owner</th><th>Manager</th><th>Address</th><th>City</th><th>Zip</th><th>Rooms</th><th>Rent</th><th>Status</th></tr>\n\t";
	while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "<tr>\n";
		
		echo "\t\t<td>$row[0]</td>\n";
		echo "\t\t<td>$row[1]</td>\n";
		echo "\t\t<td>$row[2]</td>\n";
		echo "\t\t<td>$row[3]</td>\n";
		echo "\t\t<td>$row[4]</td>\n";
		echo "\t\t<td>$row[5]</td>\n";
		echo "\t\t<td>$row[6]</td>\n";
		echo "\t\t<td>$row[7]</td>\n";
		echo "\t\t<td>$row[8]</td>\n";
		echo "\t\t<td>$row[9]</td>\n";
		echo "\t</tr>";
	}
	echo "\n</table>\n";
	
	
	
	


	OCILogoff($conn);
}

?>

<!-- end PHP script -->
	</main>
</body>
</html>
