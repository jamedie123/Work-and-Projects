<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<title>Enter lease details</title>
		<link rel="stylesheet" type="text/css" href="project.css">
	</head>
	<body>
		<header>
			<h1>Happy Renter's Rental Management</h1>
		</header>
		<nav>
			 <ul>
 				<li><a id="home" class="home" href="http://students.engr.scu.edu/~jamedie/project/">Home</a></li
				><li><a id="lease" href="enter_lease.html">Create a Lease Agreement</a></li
				><li><a id="properties" href="properties.php">Properties Report</a></li
				><li><a id="supervisors" href="supervisors.php">Supervisors Report</a></li
				><li><a id="renters" href="renters.php">Renters Report</a></li
				><li><a id="misc" href="misc.php">Miscellenous</a></li
          </ul>
    	</nav>
		<div class="below-nav"></div>
		<main>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
	//  input data
	$LeaseNumber = $_POST['LeaseNumber'];
	$PropertyNumber = $_POST['PropertyNumber'];
	$SuperName = $_POST['SuperName'];
	$DEPOSITAMOUNT = $_POST['DEPOSITAMOUNT'];
	$RENTAMOUNT = $_POST['RENTAMOUNT'];
	$STARTDATE = $_POST['STARTDATE'];
	$ENDDATE = $_POST['ENDDATE'];
	$rentername = $_POST['rentername'];
	$renternumber = $_POST['renternumber'];
	$homephone = $_POST['homephone'];
	$workphone = $_POST['workphone'];
	
	//echo $STARTDATE;
	//echo $ENDDATE;
	//echo "Testing1234";
	
	
	createLease($LeaseNumber, $PropertyNumber, $renternumber, $rentername, $homephone, $workphone, $STARTDATE, $ENDDATE, $DEPOSITAMOUNT, $RENTAMOUNT, $SuperName);
	
}


function createLease($LeaseNumber, $PropertyNumber, $renternumber, $rentername, $homephone, $workphone, $STARTDATE, $ENDDATE, $DEPOSITAMOUNT, $RENTAMOUNT, $SuperName) 
{
	$conn = oci_connect( 'jamedie', 'Liveoak123', '//dbserver.engr.scu.edu/db11g' );
	if (!$conn) {
		print "<br> connection failed:";
		exit;
	}

	//echo $LeaseNumber, $PropertyNumber,$DEPOSITAMOUNT,$SuperName, $RENTAMOUNT;
	//echo '<br>';
	//echo $STARTDATE, $ENDDATE, $rentername, $renternumber, $homephone,$workphone  ;
	//echo '<br>';
	
	
	/* ---------------
	
	$query = oci_parse($conn, "Insert Into Books_Read(title,author,category,comments) values(upper(:title),upper(:author),:category,:comments)");	
	
	oci_bind_by_name($query, ':title', $title);
	oci_bind_by_name($query, ':author', $author);
	oci_bind_by_name($query, ':category', $category);
	oci_bind_by_name($query, ':comments', $comments);
	
	// Execute the query
	$res = oci_execute($query);
	if ($res)
		echo '<br><br> <p style="color:green;font-size:20px">Data successfully inserted</p>';
	else{
		$e = oci_error($query); 
        	echo $e['message']; 
	}
	OCILogoff($conn);	
	-------------------------- */
	
	
	$query = oci_parse($conn,
	"INSERT INTO LeaseAgreement (LeaseNumber,PropertyNumber,renternumber,rentername,homephone,workphone, STARTDATE, ENDDATE,DEPOSITAMOUNT,RENTAMOUNT,SuperName)
	      values(:LeaseNumber, :PropertyNumber, :renternumber, :rentername, :homephone, :workphone, TO_DATE(:STARTDATE, 'YYYY/MM/DD'), TO_DATE(:ENDDATE, 'YYYY/MM/DD'), :DEPOSITAMOUNT, :RENTAMOUNT, :SuperName)");
	
	oci_bind_by_name($query, ':LeaseNumber', $LeaseNumber);
	oci_bind_by_name($query, ':PropertyNumber', $PropertyNumber);
	oci_bind_by_name($query, ':renternumber', $renternumber);
	oci_bind_by_name($query, ':rentername', $rentername);
	oci_bind_by_name($query, ':homephone', $homephone);
	oci_bind_by_name($query, ':workphone', $workphone);
	oci_bind_by_name($query, ':STARTDATE', $STARTDATE);
	oci_bind_by_name($query, ':ENDDATE', $ENDDATE);
	oci_bind_by_name($query, ':DEPOSITAMOUNT', $DEPOSITAMOUNT);
	oci_bind_by_name($query, ':RENTAMOUNT', $RENTAMOUNT);
	oci_bind_by_name($query, ':SuperName', $SuperName);

	// Execute the query
	$res = oci_execute($query);
	if ($res)
		echo '<br><br> <p style="color:green;font-size:20px">Data successfully inserted</p>';
	else{
		$e = oci_error($query); 
        	echo $e['message']; 
	}
	
	OCILogoff($conn);	
}

?>
		</main>
	</body>
</html>
