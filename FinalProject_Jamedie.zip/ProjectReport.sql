SET PAGESIZE 100
SET LINESIZE 150 
---PROMPT **************************************************************** 
-- PROMPT Generating the Report 
cl scr;
SET TERMOUT OFF 
PROMPT *****
COLUMN curdate NEW_VALUE report_date 
SELECT TO_CHAR(SYSDATE,'dd-Mon-yyyy') curdate FROM DUAL; 
SET TERMOUT ON 

PROMPT &report_date  

COLUMN NAME HEADING 'Supervisor' FORMAT A15
COLUMN CITY HEADING 'City' FORMAT A10
COLUMN PROPERTYNUMBER HEADING 'Property' FORMAT A10
COLUMN STREETADDRESS HEADING 'Address' FORMAT A20
COLUMN RENTERNAME HEADING 'Renter' FORMAT A10
COLUMN SUPERNAME HEADING 'Supervisor' FORMAT A10
COLUMN SUPERVISOR_ID HEADING 'Supervisor' FORMAT A10
COLUMN LEASENUMBER HEADING 'LeaseNo' FORMAT A10
COLUMN MRENT HEADING 'Rent' FORMAT $99,999
COLUMN STATUS HEADING 'Status' FORMAT A10
COLUMN HOMEPHONE HEADING 'Home Phone' FORMAT 9999999999
COLUMN STARTDATE HEADING 'Start Date' FORMAT A10
COLUMN ENDDATE HEADING 'End Date' FORMAT A10
COLUMN DEPOSITAMOUNT HEADING 'Deposit' FORMAT $99,999
COLUMN RENTAMOUNT HEADING 'Rent' FORMAT $99,999
COLUMN WORKPHONE HEADING 'Work Phone' FORMAT 9999999999
COLUMN numrooms HEADING 'Rooms' FORMAT 9999999999
COLUMN Manager HEADING 'Manager' FORMAT A10

/*------------------------------------------------------------------------------------------------
Question 1
-----------------------------------------------------------------------------------------------------*/
TTITLE '1-LIST OF RENTAL PROPERTIES FOR A SPECIFIC BRANCH along W/ The MGR NAME.' skip 2
SELECT  B.BRANCHNUMBER, P.PROPERTYNUMBER, P.PropertyOwnerID, E.NAME As Manager, P.STREETADDRESS, P.CITY, P.ZIP, P.numrooms, P.mrent, P.status
FROM RentalProperty P, BRANCH B, EMPLOYEE E
where upper(B.BranchNumber)=upper('Branch1') and B.MANAGERID=E.EMPLOYEEID and P.supervisor_id= B.SUPERVISORID and B.MANAGERID=E.EMPLOYEEID AND P.STATUS='Available';

/*----------------------------------------------------------------------------------------------------
Question 2
-----------------------------------------------------------------------------------------------------*/
TTITLE '2-LIST OF SUPERVISORS AND PROPERTIES' skip 2
select E.NAME, PROPERTYNUMBER, STREETADDRESS, CITY, ZIP  from RentalProperty, employee E
where SUPERVISOR_ID=E.EMPLOYEEID;

/*----------------------------------------------------------------------------------------------------
Question 3
-----------------------------------------------------------------------------------------------------*/
TTITLE '3-LIST of rental properties by a specific owner (owner1), listed in a happyRenter’s branch' skip 2
SELECT PropertyOwnerID, PROPERTYNUMBER, STREETADDRESS FROM RentalProperty
WHERE PropertyOwnerID = 'owner1';

/*----------------------------------------------------------------------------------------------------
Question 4
-----------------------------------------------------------------------------------------------------*/
TTITLE '4-listing of properties available, where the properties should satisfy the criteria' skip 2
SELECT * FROM RentalProperty
WHERE upper(status) = upper('available')
AND upper(city) = upper('San Jose')
AND numrooms = 3
AND mrent BETWEEN 300 AND 8000;

/*----------------------------------------------------------------------------------------------------
Question 5
-----------------------------------------------------------------------------------------------------*/
TTITLE skip 2 '5-NUMBER OF AVAILABLE PROPERTIES' skip 2
SELECT COUNT(*) as Available_Properties FROM RentalProperty
WHERE upper(status) = upper('available');

/*----------------------------------------------------------------------------------------------------
Question 6
-----------------------------------------------------------------------------------------------------*/
TTITLE skip 2 '6-Create a lease agreement' skip 2
/* Entre this in the GUI
Lease7  
Property3
SuperVisor=Dan
Deposit=AnyAmount  
Rent=AnyAmout
StartDate=01/01/2018  
EndDate=07/15/2018
RenterNo= Renter5
Renter=  Mike
*/

/*----------------------------------------------------------------------------------------------------
Question 7
-----------------------------------------------------------------------------------------------------*/
TTITLE skip 2 '7-LEASE AGREEEMNENT FOR A RENTER' skip 2
select * from LeaseAgreement where rentername='Daniel';

/*----------------------------------------------------------------------------------------------------
Question 8
-----------------------------------------------------------------------------------------------------*/
TTITLE skip 2 '8-RENTERS WITH MORE THAN ONE RENTAL PROPERTY' skip 2
SELECT rentername FROM LeaseAgreement GROUP BY rentername HAVING COUNT(*) > 1;

/*----------------------------------------------------------------------------------------------------
Question 9
-----------------------------------------------------------------------------------------------------*/
TTITLE skip 2 '9-AVERAGE RENT for PROPERTIES IN A TOWN ' skip 2
SELECT AVG(MRENT) as Average_Rent, city FROM RentalProperty GROUP BY city;

/*----------------------------------------------------------------------------------------------------
Question 10
-----------------------------------------------------------------------------------------------------*/
TTITLE skip 2 '10-NAMES AND ADDRESS OF PROPERTIES WITH LEASE EXPIRING in 2 MONTHS' skip 2
SELECT rentername, STREETADDRESS, CITY, ZIP 
FROM LeaseAgreement L INNER JOIN RentalProperty P ON L.PROPERTYNUMBER = P.PROPERTYNUMBER
WHERE (ENDDATE - SYSDATE) < 60;

