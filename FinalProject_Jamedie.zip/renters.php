<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
	<title>Happy Renter's Rental Management</title>
	<link rel="stylesheet" type="text/css" href="project.css">
</head>
<body>
	<header>
		<h1>Happy Renter's Rental Management</h1>
	</header>
	<nav>
		<ul>
 			<li><a id="home" class="home" href="http://students.engr.scu.edu/~jamedie/project/">Home</a></li
			><li><a id="lease" href="enter_lease.html">Create a Lease Agreement</a></li
			><li><a id="properties" href="properties.php">Properties Report</a></li
			><li><a id="supervisors" href="supervisors.php">Supervisors Report</a></li
			><li><a id="renters" class="current" href="renters.php">Renters Report</a></li
			><li><a id="misc" href="misc.php">Miscellenous</a></li
         </ul>
	</nav>
	<div class="below-nav"></div>
	<main>

<?php

properties();

function properties() {
	$conn=oci_connect( 'jamedie', 'Liveoak123', '//dbserver.engr.scu.edu/db11g' );
	if(!$conn) {
		print "<br> connection failed:";
		exit;
	}

	$query = oci_parse($conn,"select * from LeaseAgreement order by LeaseNumber");
	

	echo '<h2 id="query">Lease Agreement for Renters</h2>';
	oci_execute($query);
	echo "\n<table>\n";
	echo "\t<tr><th>Lease</th><th>Property</th><th>RenterID</th><th>Renter</th><th>Home Phone</th><th>Work Phone</th><th>StartDate</th><th>EndDate</th><th>Deposit</th><th>Rent</th><th>Supervisor</th></tr>\n\t";
	while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "<tr>\n";
		
		echo "\t\t<td>$row[0]</td>\n";
		echo "\t\t<td>$row[1]</td>\n";
		echo "\t\t<td>$row[2]</td>\n";
		echo "\t\t<td>$row[3]</td>\n";
		echo "\t\t<td>$row[4]</td>\n";
		echo "\t\t<td>$row[5]</td>\n";
		echo "\t\t<td>$row[6]</td>\n";
		echo "\t\t<td>$row[7]</td>\n";
		echo "\t\t<td>$row[8]</td>\n";
		echo "\t\t<td>$row[9]</td>\n";
		echo "\t\t<td>$row[10]</td>\n";
		echo "\t</tr>";
	}
	echo "\n</table>\n";

	$query = oci_parse($conn,"SELECT rentername FROM LeaseAgreement GROUP BY rentername HAVING COUNT(*) > 1");
	
    echo "<br><br>";
	echo '<h4 id="query">Renters with More than one Rental Agreement</h4>';
	oci_execute($query);
	echo "\n<table>\n";
	echo "\t<tr><th>Renter</th></tr>\n\t";
	while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "<tr>\n";
		
		echo "\t\t<td>$row[0]</td>\n";
		echo "\t</tr>";
	}
	echo "\n</table>\n";

	OCILogoff($conn);
}

?>
<!-- end PHP script -->
	</main>
</body>
</html>
