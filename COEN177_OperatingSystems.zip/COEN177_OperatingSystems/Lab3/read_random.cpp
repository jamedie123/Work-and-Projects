/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 3
Date :     2/13/18
Purpose:   This program will read a large file randomly
******************************************************************************************/
#include <iostream>
#include <stdlib.h>
#include <cstdio>

int main (int argc, char*argv[]) 
{
	if (argc < 2) {
		std::cout << "You need to enter the file name\n";
		exit(1); 	}
 	
FILE * file;
int fsize;
int r =0;

srand(time(NULL));


file = fopen(argv[1], "r");
	if ( file == NULL)
	 {
	     std::cout << "Error opening " << argv[1]  << std::endl;
	     exit(1); 	
	}
	else
	{
	     fseek(file, 0, SEEK_END);
	     fsize = ftell(file);
         rewind(file);

		for(int i=0; i < fsize ; i++)
		{
		  fseek(file, (rand()% fsize), SEEK_SET );
		  r = getc(file);
		}
}
	fclose(file) ;
	return 0;
}