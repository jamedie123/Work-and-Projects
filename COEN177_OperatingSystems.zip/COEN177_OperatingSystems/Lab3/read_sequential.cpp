/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 3
Date :     2/13/18
Purpose:   This program will read a large file sequentially
******************************************************************************************/

#include <iostream>
#include <stdlib.h>
#include <stdio.h>

int main (int argc, char*argv[]) 
{
	if (argc < 2) {
		std::cout << "You need to enter the file name\n";
		exit(1); 	}
 	
FILE * file;
int fileSize;
int c =0;

srand(time(NULL));

file = fopen(argv[1], "r");
	if ( file == NULL)
	{
	     std::cout << "Error opening " << argv[1]  << std::endl;
	     exit(1); 	
	}
	else
	{
        while ( getc(file) != -1);
	}
	fclose (file);
	return 0;  
}