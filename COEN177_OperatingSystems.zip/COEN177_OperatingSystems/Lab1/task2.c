/****************************************************************************************
Name:    Jacob Amedie 
Teacher: Professor Amer Ahmid
COEN177: Lab 1 Part 2
Date :   1/23/18
Purpose: This program allows 
**********************************************************************************************/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include<stdlib.h>
#include<unistd.h>


int main() {
	printf("\nInitial Process is: %d\n\n" , getpid() );

	int i;
	int pid;
	for( i = 0 ; i < 8 ; i++ ) {
		if( ( pid = fork() ) != 0 ) {
			wait(NULL);
			break; /* Enforces the parents not to go through the rest of the for loop. */
		} else {
			printf("My Child is %d \t - My Parent is %d\n" , getpid() , getppid() );
		}
	}
}