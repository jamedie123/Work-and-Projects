/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 1 Part 1
Date :     1/23/18
Purpose:   This program creates a simple shell program that allows user to enter a command and launch a program in response to an input command. User will enter a unix command /bin/ls or /bin/pwd and the program should execute. 
I also used the executable from  “hello world” program, to test from shell. The shell should terminate if the user enters “exit” at the command line. 
******************************************************************************************/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include<stdlib.h>
#include<unistd.h>

void print_prompt();
void read_command( char* command );

int main() {
  
    while(1) {
        char cmd[300];
        print_prompt();
        read_command(cmd);

        if( strcmp(cmd , "exit" ) == 0 ) {
            printf("Quitting.\n");
            exit(0);
        }

        if( fork() != 0 ) 
            wait(NULL); //Wait for child process to terminate 
        else {
            char** param = {NULL};
            int Val = execve( cmd , param, 0 ); //Checks if successful
            if( Val < 0 ) 
	    {
                printf("Error in commmand.\n");
                exit(Val);
            }
            exit(0); //Exit So the childprocess will start a new program 
        }
    }

}


void print_prompt() {
    printf("#### ");
}

void read_command( char* command ) {
    fgets( command , 255 , stdin );
    char* p = strchr(command , '\n'); //Determine where command ends
    *p = '\0'; //Add null to make a string.
}
