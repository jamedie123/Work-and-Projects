/****************************************************************************************
Name:    Jacob Amedie 
Teacher: Professor Amer Ahmid
COEN177: Lab 1 Part 3
Date :   1/23/18
Purpose: This program allows 
**********************************************************************************************/
#include <stdio.h>
#include <time.h>
#include <string.h>
#include<stdlib.h>
#include<unistd.h>


int main() {
		int i;
	int level = 1;
	int maxHeight = 3;
	int children = 3;

	for( i = 0 ; i < children ; i++ ) {
	
		int pid = fork();
		
		if( pid == 0 ) { /* Child Process. */
			level = level + 1;
			printf("Child is %d \t Parent is %d\n" , getpid() , getppid() );
			if( i == 1 && level == 2 ) {
				children = 2;
			} else {
				children = 3;
			}

			i = -1; /* Change 'i' to -1 so that each child about to be forked in the iteration will 'children'. */

		} else {
			wait(NULL); /*If parent, have it wait so it doesn't get killed - prevents parent id from becoming '1'. */
		}

		if( level >= maxHeight ) {
			exit(0); /* Once at the third level, do not create any more children. */
		}

	}
}
	