/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 5: Program 1
Date :     3/20/18
Purpose:   This is program One: It will use the Pre-Lab data mapping and 
           outputs the String Lenght, the String, and its hashed value by the next string hashed + prev hash
		   ie: (strLength)(string)(hash(string))(hash(string+prevHash))
******************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "Hasher.h"

void trackHash(char buffer1[], char buffer2[], char * key1, char * key2, unsigned char * hashValue, unsigned char * prevValue);

int main(int argc, char *argv[]) 
{
   // The user needs to enter a string at the command line argument
   if(argc<2){
     	printf("\nPlease provide a string to be hashed\n\n");
		exit(1); 	}
	

	int hashLen;
	unsigned char *hashValue, *prevValue = "\0";
	Hasher *h = createHasher();

	char buffer1[500], buffer2[1000];
	char *key1 = buffer1, *key2 = buffer2;
	size_t buffer_size = 500;
	
	while(1) 
	{
		getline(&key1,&buffer_size,stdin);
		
		if(feof(stdin))
			break;
	
		//printf("Len %d  String %s\n",strlen(buffer),buffer);
		//printf("Length = %d  String = %s was hashed to ",strlen(argv[1]),argv[1]);
		
		if(strlen(buffer1) < 10)
			printf("00%d%s",strlen(buffer1),buffer1);
		else if (strlen(buffer1) >= 10 && strlen(buffer1) < 100) 
			printf("0%d%s",strlen(buffer1),buffer1);
		else if (strlen(buffer1) > 100) 
			printf("%d%s",strlen(buffer1),buffer1);
		
    	hashLen = h->hash(buffer1, &hashValue);
		printHash(hashValue,hashLen);
		trackHash(buffer1,buffer2,key1,key2,hashValue, prevValue);
    	printHash(hashValue, hashLen);
	}
	
	free(hashValue);
	cleanup(h);
	
	return 0;
}

void trackHash(char buffer1[], char buffer2[], char * key1, char * key2, unsigned char * hashValue, unsigned char * prevValue)
{
    int hashLen;
	Hasher *h = createHasher();
	memcpy(key2, key1, strlen(buffer1));
	memcpy(key2+strlen(buffer1),prevValue, strlen(buffer2));	
	hashLen = h->hash(key2, &hashValue);
	prevValue = hashValue;
}
