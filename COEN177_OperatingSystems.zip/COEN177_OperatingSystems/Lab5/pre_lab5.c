/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 5: PreLab 
Date :     3/20/18
Purpose:   This program will accept a string and outputs the hashed result using 
           a data mapping structure by storing the keys and values.
******************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "Hasher.h"

int main(int argc, char *argv[]) {
	
	// The user needs to enter a string at the command line argument
	if(argc<2){
     	printf("\nPlease provide a string to be hashed\n\n");
		exit(1); 	}

	unsigned char *hashValue;
	int hashLen;
	Hasher *h = createHasher();
	char buffer[500];
	char *key = buffer;
	size_t buffer_size = 500;
	
	while(1) {
		getline(&key,&buffer_size,stdin);
		if(feof(stdin))
			break;
		
		//printf("Len %d  String %s\n",strlen(buffer),buffer);
		//printf("Length = %d  String = %s was hashed to ",strlen(argv[1]),argv[1]);
		
		printf("%d%s",strlen(buffer),buffer);
			
		// hashLen = h->hash(argv[1], &hashValue);
    	hashLen = h->hash(buffer, &hashValue);
		printHash(hashValue,hashLen);
	}
	
 	printf("\n");

	cleanup(h);
	free(hashValue);

	return 0;
}