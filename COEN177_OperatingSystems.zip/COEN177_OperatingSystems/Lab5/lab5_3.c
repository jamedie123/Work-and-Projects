/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 5: Program 3
Date :     3/18/18
Purpose:   This is program Three:It takes the output file from Program1 
           and prints if there are strings missing. 
******************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "Hasher.h"

unsigned char readHashData(FILE *fp) ;
void trackHash(char buffer1[], char buffer2[], char * key1, char * key2, unsigned char * hashValue, unsigned char * prevValue);

int main(int argc, char *argv[]) 
{
  
   // The user needs to the file with hash result at the command line argument
   if(argc<2){
     	printf("\nPlease provide the file name of hashed data\n\n");
		exit(1); 	}

	unsigned char *hashValue, *checkHash;
	unsigned char *prevValue = "\0";
	int hashLen1, hashLen2, HashLen;
	
	Hasher *h = createHasher();
	
	char buffer1[500], buffer2[1000];
	char *key1 = buffer1, *key2 = buffer2;
	size_t buffer_size = 500;
	char *hash1,*hash2;
	
	hash1 = (char*) malloc(sizeof(char)*128);
	hash2 = (char*) malloc(sizeof(char)*128);
	
	FILE * fp;
	fp = fopen(argv[1],"r");
	
	char length[3];
	fread(length,sizeof(char), 3, fp);
	
	while(!feof(fp))
	{		
		char length[3];
		length[0] = '\0';
		fread(length,sizeof(char), 3, fp);
		int temp, i;
		
		if((temp = atoi(length)) <= 0)
			break;
		
		fread(buffer1,sizeof(char), temp, fp);
		HashLen = h->hash(buffer1, &checkHash);

		trackHash(buffer1,buffer2,key1,key2,hashValue,prevValue);
		fread(hash2,sizeof(char), 2*HashLen, fp);
		
		for(i = 0; i < HashLen; i++) 
		{
			if(checkHash[i] != readHashData(fp)) {
				printf("Omission was detected\n");
				free(hash1);
				free(hash2);
				return;
			}
			else
				printf("No Omission was detected\n");
		}
	}
	free(hash1);
	free(hash2);
	cleanup(h);
	   
	return 0;
}

void trackHash(char buffer1[], char buffer2[], char * key1, char * key2, unsigned char * hashValue, unsigned char * prevValue)
{
    int hashLen;
	Hasher *h = createHasher();
	memcpy(key2, key1, strlen(buffer1));
	memcpy(key2+strlen(buffer1),prevValue, strlen(buffer2));	
	hashLen = h->hash(key2, &hashValue);
	prevValue = hashValue;
}

unsigned char readHashData(FILE *fp) 
{
        int data1 = fgetc(fp), data2 = fgetc(fp);
        char temp_data[2];
        
		if(data1 == EOF || data2 == EOF) 
            fprintf(stderr, "End of File is reached!\n");
           
        temp_data[0] = (char)data1;
        temp_data[1] = (char)data2;
        
		return (unsigned char)strtol(temp_data, NULL, 16);
}

