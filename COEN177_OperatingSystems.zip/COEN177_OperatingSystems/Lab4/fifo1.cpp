/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 4
Date :     2/27/18
Purpose:   This program will test FIFO Page Replacement Algorithm
******************************************************************************************/
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <deque>

using namespace std;
#define MAX_MEM 500

int checkMem(int page, std::deque<int> pageTable, int tableSize);
	
int main(int argc, char *argv[])
{
		if(argc<2){
     	std::cout << "Provide Talbe Size\n";
		exit(1); 	}
	
	int tableSize=atoi(argv[1]);
	
	if(tableSize>MAX_MEM){
		tableSize=MAX_MEM;
	}
	int pageRequest, pageTableIndex=0, fault = 0, mem_access = 0;
	std::deque<int> pageTable(tableSize);
	char *input=NULL;
	size_t inputAllocated;
	ssize_t bytesRead;

	while((bytesRead = getline(&input, &inputAllocated, stdin)) !=EOF){
		
		pageRequest=atoi(input);
		mem_access++;
		if(pageRequest==0){
		}
		else if(!checkMem(pageRequest, pageTable, tableSize)){
			fault++;
			std::cout << "Page " << pageRequest << " has page fault. " << std::endl;
			
			if(pageTableIndex<tableSize){
				pageTable[pageTableIndex++]=pageRequest;
			}
			/*if pageTable full then implement page replacement algorithm*/
			else{
				pageTable.pop_front();
				pageTable.push_back(pageRequest);
			}
		}
	}
	 std::cout << "\nNumber of Page Request: " << mem_access << std::endl;
	std::cout << "Number of Page fault: " << fault << std::endl;
	
	return 0;
}

int checkMem(int page, std::deque<int> pageTable, int tableSize){
	int i;
	for(i=0;i<tableSize;i++){
		if(pageTable[i] == page){
			return 1;
		}
	}
	return 0;
}