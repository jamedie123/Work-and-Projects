/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 4
Date :     2/27/18
Purpose:   This program will test FIFO Page Replacement Algorithm
******************************************************************************************/
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <deque>
#define MAX_MEM 500

int checkMem(int page, int tblSize, std::deque<int> pgTbl);
	
int main(int argc, char *argv[])
{
		if(argc<2){
     	std::cout << "Provide Talbe Size\n";
		exit(1); 	}
	
	int tblSize=atoi(argv[1]);
	
	if(tblSize>MAX_MEM)
		tblSize=MAX_MEM;
	
	int pgReq, index=0, fault = 0, mem_access = 0;
	std::deque<int> pgTbl(tblSize);
	char *input=NULL;
	size_t allocated;
	ssize_t nRead;

	while((nRead = getline(&input, &allocated, stdin)) !=EOF)
	{
		
		pgReq=atoi(input);
		mem_access++;
		if(pgReq==0){
		}
		else if(!checkMem(pgReq, tblSize, pgTbl))
		{
			fault++;
			std::cout << "Page " << pgReq << " has page fault. " << std::endl;
			
			if(index<tblSize)
				pgTbl[index++]=pgReq;
			else
			{
				pgTbl.pop_front();
				pgTbl.push_back(pgReq);
			}
		}
	}
	std::cout << "\nNumber of Page Request: " << mem_access << std::endl;
	std::cout << "Number of Page fault: " << fault << std::endl;
	
	return 0;
}

int checkMem(int page, int tblSize, std::deque<int> pgTbl){

	for(int i=0;i<tblSize;i++)
	{
		if(pgTbl[i] == page)
			return 1;
	}
	return 0;
}