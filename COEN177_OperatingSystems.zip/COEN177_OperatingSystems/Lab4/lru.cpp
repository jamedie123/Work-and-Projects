/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 4
Date :     2/27/18
Purpose:   This program will test an LRU Page Replacement Algorithm
******************************************************************************************/
#include <stdio.h>
#include <iostream>
#include <time.h>
#include <stdlib.h>
#define MAX_MEM 500

struct pageReq
{
	int clock;
	int page;
};

int checkMem(int page, int tblSize, struct pageReq pgTbl[]);

int main(int argc, char *argv[])
{
	if(argc<2){
     	std::cout << "Provide Talbe Size\n";
		exit(1); 	}
	
	
	int tblSize=atoi(argv[1]);
	
	if(tblSize>MAX_MEM)
		tblSize=MAX_MEM;
	
	
	int pgReq, index=0, fault = 0, mem_access = 0;
	struct pageReq pgTbl[MAX_MEM];
	char *input=NULL;
	size_t allocated;
	ssize_t nRead;

        
	while((nRead = getline(&input, &allocated, stdin)) !=EOF)
	{

		pgReq=atoi(input);
		mem_access++;
		
		if(pgReq==0){
		}
		else if(!checkMem(pgReq, tblSize, pgTbl))
		{
			fault++;
			std::cout << "Page " << pgReq << " has page fault. " << std::endl;
		
			if(index < tblSize)
			{
				pgTbl[index++].page=pgReq;
				pgTbl[index].clock=(int) time(NULL);
			}
			else
			{
				int j = pgReq, LRU = 0, oldest=pgTbl[0].clock;
				
				for(int i=0;i<tblSize;i++)
				{
					if(pgTbl[i].clock<oldest)
					{
						oldest=pgTbl[i].clock;
						LRU=i;
					}
				}
				
				for(int i=LRU; i<tblSize; i++)
				{
					pgTbl[i].page=pgTbl[i+1].page;
					pgTbl[i].clock=pgTbl[i+1].clock;
				}
				
				pgTbl[tblSize-1].page=j;
				pgTbl[tblSize-1].clock=(int) time(NULL);
			}
		}
	}
	
	std::cout << "\nNumber of Page Request: " << mem_access << std::endl;
	std::cout << "Number of Page fault: " << fault << std::endl;
    
	return 0;
}

int checkMem(int page, int tblSize, struct pageReq pgTbl[])
{
	for(int i=0;i <tblSize ;i++)
	{
		if(pgTbl[i].page == page){
			pgTbl[i].clock=(int) time(NULL);
			return 1;
		}
	}
	return 0;
}