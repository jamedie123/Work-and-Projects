/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 4
Date :     2/27/18
Purpose:   This program will test an LFU Page Replacement Algorithm
******************************************************************************************/
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#define MAX_MEM 500

struct pageReq
{
	int count;
	int page;
};

int checkMem(int page, int tblSize, struct pageReq pgTbl[]);

int main(int argc, char *argv[])
{
	if(argc<2){
     	std::cout << "Provide Talbe Size\n";
		exit(1); 	}
	
	int tblSize=atoi(argv[1]);
	
	if(tblSize>MAX_MEM)
		tblSize=MAX_MEM;
	
	
	int pgReq, index=0, fault = 0, mem_access = 0;
	struct pageReq pgTbl[MAX_MEM];
	char *input=NULL;
	size_t allocated;
	ssize_t nRead;

	while((nRead = getline(&input, &allocated, stdin)) !=EOF)
	{
		pgReq=atoi(input);
		mem_access++;
		
		if(pgReq==0){
		}
		else if(!checkMem(pgReq, tblSize, pgTbl))
		{
			fault++;
			std::cout << "Page " << pgReq << " has page fault. " << std::endl;
			
			if(index < tblSize)
			{
				pgTbl[index++].page=pgReq;
				pgTbl[index].count=0;
			}
			else{
				int j=pgReq, LFU=0, least=pgTbl[0].count;
				
				for(int i=0; i<tblSize ;i++)
				{
					if(pgTbl[i].count<least)
					{
						least=pgTbl[i].count;
						LFU = i;
					}
				}
				for(int i=LFU;i<tblSize;i++){
					pgTbl[i].page=pgTbl[i+1].page;
					pgTbl[i].count=pgTbl[i+1].count;
				}
				pgTbl[tblSize-1].page=j;
				pgTbl[tblSize-1].count=0;

			}
		}
	}
	
	std::cout << "\nNumber of Page Request: " << mem_access << std::endl;
	std::cout << "Number of Page fault: " << fault << std::endl;
	
	return 0;
}


int checkMem(int page, int tblSize, struct pageReq pgTbl[])
{
	for(int i=0; i <tblSize ;i++)
	{
		if(pgTbl[i].page == page)
		{
			pgTbl[i].count++;
			return 1;
		}
	}
	return 0;
}