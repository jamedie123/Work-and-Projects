/****************************************************************************************
Name:      Jacob Amedie 
Professor: Ahmed Amer
TA:        Muna Sinada
COEN177:   Lab 4
Date :     2/27/18
Purpose:   This program will test an Random Page Replacement Algorithm
******************************************************************************************/
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#define MAX_MEM 500

int checkMem(int page, int tblSize, int *pgTbl);


int main(int argc, char *argv[])
{
	if(argc<2){
     	std::cout << "Provide Talbe Size\n";
		exit(1); 	}
	
	int tblSize=atoi(argv[1]);
	
	if(tblSize>MAX_MEM)
		tblSize=MAX_MEM;
	
	int pgReq, index=0, fault = 0, mem_access = 0;
    int *pgTbl = new int[tblSize];
	char *input=NULL;
	size_t allocated;
	ssize_t nRead;

	while((nRead = getline(&input, &allocated, stdin)) !=EOF){
	    mem_access++;
		pgReq=atoi(input);
		
		if(pgReq==0){
		}
		else if(!checkMem(pgReq, tblSize, pgTbl))
		{
			fault++;
			std::cout << "Page " << pgReq << " has page fault. " << std::endl;
			
			if(index<tblSize)
			{
				pgTbl[index++]=pgReq;
			}
			else
			{
				int k=pgReq;
				int j=rand() % (tblSize-1);
				
				for(int i=j;i<tblSize;i++)
				{
					pgTbl[i]=pgTbl[i+1];
				}
				pgTbl[tblSize-1]=k;
			}	
		}
	}
	
    std::cout << "\nNumber of Page Request: " << mem_access << std::endl;
	std::cout << "Number of Page fault: " << fault << std::endl;
	
	delete[] pgTbl;
	return 0;
}


int checkMem(int page, int tblSize, int *pgTbl)
{
	for(int i=0; i <tblSize ;i++)
	{
		if(pgTbl[i] == page)
		{
			return 1;
		}
	}
	return 0;
}