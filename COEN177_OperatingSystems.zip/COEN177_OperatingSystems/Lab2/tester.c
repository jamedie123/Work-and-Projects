#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

int main(int argc, char** argv) {
	int pid, i = 0, cnt = 0;
	
	while(i < 6) {   // fork several times
		
		pid = fork();
		printf("PID: %d\n", pid);
		
		cnt = 0;
		
		while(cnt<10000) {   // loop to help padding
			cnt++;
		}
		i++;
	}
	return 0;
} 

/* Expected behavior:
	standard: print PIDs in order
	random: random distribution of PID prints
*/
