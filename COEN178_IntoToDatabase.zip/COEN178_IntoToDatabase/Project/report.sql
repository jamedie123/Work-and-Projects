SET PAGESIZE 100
SET LINESIZE 100 
PROMPT **************************************************************** 

PROMPT Generating the Report 

SET TERMOUT OFF 

COLUMN curdate NEW_VALUE report_date 
SELECT TO_CHAR(SYSDATE,'dd-Mon-yyyy') curdate
 FROM DUAL; 
SET TERMOUT ON 

PROMPT &report_date 

TTITLE skip 2 CENTER 'Suppliers in a City' skip 2
COLUMN NAME FORMAT A15
COLUMN CITY FORMAT A10
COLUMN STREETADDRESS HEADING 'ADDRESS' FORMAT A20
COLUMN RENTERNAME HEADING 'Renter'FORMAT A10
COLUMN SUPERNAME HEADING 'Supervisor' FORMAT A10
COLUMN SUPERNAME HEADING 'Supervisor' FORMAT A10

TTITLE skip 2 CENTER 'List of Supervisors and properties' skip 2
select E.NAME as Supervisor, PROPERTYNUMBER, STREETADDRESS, CITY, ZIP  from RentalProperty, employee E
 where SUPERVISOR_ID=E.EMPLOYEEID;

TTITLE skip 2 CENTER 'Number of Properties Available' skip 2
SELECT COUNT(*) FROM Rental_Property
WHERE status = 'available';


