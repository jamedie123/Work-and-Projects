CREATE TABLE Branch(
	BranchNumber		INTEGER PRIMARY KEY,
	Phone				INTEGER,
	StreetAddress		VARCHAR(50),
	City				VARCHAR(50),
	Zip					INTEGER,
);

CREATE TABLE Employee(
	EmployeeID			INTEGER PRIMARY KEY,
	Name				VARCHAR(20),
	Phone				INTEGER,
	StartDate			DATE,
	JobDesignation		VARCHAR(20),
	BranchNumber		INTEGER,
	FOREIGN KEY (BranchNumber) REFERENCES Branch(BranchNumber)
);

CREATE TABLE PropertyOwner(
	PropertyOwnerID		INTEGER PRIMARY KEY,
	Name 				VARCHAR(20),
	StreetAddress		VARCHAR(50),
	City				VARCHAR(50),
	Zip					INTEGER,
	Phone				INTEGER,
);

CREATE TABLE RentalProperty(
	PropertyNumber		INTEGER PRIMARY KEY,
	PropertyOwnerID		INTEGER,
	StreetAddress		VARCHAR(50),
	City				VARCHAR(50),
	Zip					INTEGER,
	NumRooms	    	INTEGER,
	MRent   			NUMBER(12,2),
	Status				VARCHAR(20) CHECK (Status IN ('Available','Leased')),
	AvailStartDate		DATE,
	SupervisorEmpID		INTEGER,
	FOREIGN KEY (SuperEmpID) REFERENCES Employee(EmployeeID)
);

CREATE TABLE LeaseAgreement(
	PropertyNumber		INTEGER,
	RenterName			VARCHAR(20),
	HomePhone			INTEGER ,
	WorkPhone			INTEGER ,
	StartDate 			DATE,
	EndDate 			DATE,
	DepositAmount		NUMBER(7,2),
	RentAmount			NUMBER(7,2),
	SuperName			VARCHAR(20),
	FOREIGN KEY (PropertyNumber) REFERENCES RentalProperty(PropertyNumber),
);