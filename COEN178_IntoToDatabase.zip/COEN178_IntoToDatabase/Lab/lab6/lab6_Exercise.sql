/************************************************************
Part 1  
************************************************************/

Create table BANKCUST_6 (custno VARCHAR(5) Primary Key, custname VARCHAR(20),
street VARCHAR(30), city VARCHAR(20));

Create table ACCOUNTS_6 (AccountNo VARCHAR(5) Primary Key, accountType VARCHAR(10),
amount NUMBER(10,2), custno VARCHAR(5), CONSTRAINT accounts_fkey Foreign Key (custno)
REFERENCES BANKCUST_6(custno));

Create table TOTALS_6 (custno VARCHAR(5), totalAmount NUMBER(10,2),
CONSTRAINT totals_fkey Foreign Key (custno) REFERENCES BANKCUST_6(custno));

/*********************************************
Exercise 1
**********************************************/
CREATE or REPLACE TRIGGER display_customer_trig
    AFTER INSERT on BankCust_6
    FOR EACH ROW
BEGIN
    DBMS_OUTPUT.PUT_LINE('From Trigger ' || 'Customr NO: ' ||
    :new.custno || ' Customer Name: ' || :new.custname || ' Customer City: ' || :new.City);
END;
/
show errors;

insert into BANKCUST_6 values('c1','Smith','32 Lincoln st','SJ');
insert into BANKCUST_6 values('c2','Jones','44 Benton st','SJ');
insert into BANKCUST_6 values('c3','Peters','12 palm st','SFO');
insert into BANKCUST_6 values('c20','Chen','20 san felipo','LA');
insert into BANKCUST_6 values('c33','Williams',' 11 cherry Ave','SFO');

/***********************
Did your trigger work?
Yes
***************************/

/*********************************************
Exercise 2
**********************************************/


Alter trigger display_customer_trig disable;

CREATE OR REPLACE TRIGGER Acct_Cust_Trig
    AFTER INSERT ON Accounts_6
    FOR EACH ROW
BEGIN
    /* If the custno is already in the Totals_6 table, the update will succeed */
    update totals_6
    set totalAmount = totalAmount + :new.amount
    where custno = :new.custno;

    /* If the custno is not in the Totals_6 table, we insert a row into Totals_6
    table. Complete the missing part in the subquery */
    insert into totals_6 (select :new.custno, :new.amount from dual
        where not exists (select * from Totals_6 where custno= :new.custno));
END;
/
show errors;

delete from ACCOUNTS_6;
delete from totals_6;

insert into ACCOUNTS_6 values('a1523','checking',2000.00,'c1');
insert into ACCOUNTS_6 values('a2134','saving',5000.00,'c1');
insert into ACCOUNTS_6 values('a4378','checking',1000.00,'c2');
insert into ACCOUNTS_6 values('a5363','saving',8000.00,'c2');
insert into ACCOUNTS_6 values('a7236','checking',500.00,'c33');
insert into ACCOUNTS_6 values('a8577','checking',150.00,'c20');

select * from totals_6;
/**************************************************
Did your trigger work? How did you check? 
Yes, we check with the totals_6 table

Show the data in Totals_6 table.
select * from totals_6;

What is the amount for the customer, ‘c1’?
70000

Does the total amount for ‘c1’ agree with the amounts 
for that customer in the Accounts_6 table?
Yes it does...
********************************************/

/*********************************************
Exercise 3
**********************************************/

update Accounts_6
  set amount = 1000
  where accountno = 'a1523';

select * from ACCOUNTS_6;
/************************************************************
What is the amount for the customer, ‘c1’?
6000
Does the amount in Totals_6 table for ‘c1’ agree with the total of amounts in all the accounts for ‘c1’ in Accounts_6 table?
Yes, it does
**************************************************************/

/*********************************************
Exercise 4
**********************************************/


CREATE OR REPLACE TRIGGER Acct_Cust_Trig
    AFTER INSERT OR UPDATE ON ACCOUNTS_6
    FOR EACH ROW
BEGIN
    If inserting then
        update totals_6
        set totalAmount = totalAmount + :new.amount
        where custno = :new.custno;

        insert into totals_6 (select :new.custno, :new.amount from dual
            where not exists (select * from Totals_6 where custno= :new.custno));
    END IF;

    If updating then
        /* if we are updating we want to correctly set the totalAmount
        to the new amount that may be >= or < old amount.
        Complete the query */
        update totals_6
        set totalAmount = totalAmount + :new.amount - :old.amount
        where custno = :new.custno;
    END IF;
END;
/
Show Errors;

delete from ACCOUNTS_6;
delete from TOTALS_6;

insert into ACCOUNTS_6 values('a1523','checking',2000.00,'c1');
insert into ACCOUNTS_6 values('a2134','saving',5000.00,'c1');
insert into ACCOUNTS_6 values('a4378','checking',1000.00,'c2');
insert into ACCOUNTS_6 values('a5363','saving',8000.00,'c2');
insert into ACCOUNTS_6 values('a7236','checking',500.00,'c33');
insert into ACCOUNTS_6 values('a8577','checking',150.00,'c20');

select * from totals_6;

update Accounts_6
set amount = 1000
where accountno = 'a1523';

select * from totals_6;
select * from accounts_6;

/**********************************
d)What is the amount for the customer, ‘c1’?
  7000
e) Run this query
   update Accounts_6
   set amount = 1000
   where accountno = 'a1523';
f) If the above query successfully ran, check the Totals_6 table.
    select * from totals_6;
g) What is the amount for the customer, ‘c1’?
   6000. 
h) Does the amount in Totals_6 table for‘c1’agree with the total of amounts in all the accounts for ‘c1’ in Accounts_6 table?
   Yes it does
   
*********************************************/

/*********************************************
Exercise 5
**********************************************/

CREATE OR REPLACE TRIGGER NoUpdatePK_trig
    AFTER UPDATE ON BANKCUST_6
    FOR EACH ROW
BEGIN
    if updating ('custno') then
        raise_application_error (-20999, 'Cannot update a Primary Key');
    END IF;
END;
/
show errors;

UPDATE BANKCUST_6
SET custno='c99'
WHERE custno='c1';

/***********************************************
What is the result? 
Is the custno updated?
No, the custno is not updated - 
I am getting an error mesg "Cannot update a Primary Key"

********************************************************/
