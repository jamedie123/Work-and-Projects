<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
      <title>Get Book Highlights</title>
   </head>
   <body>
   <!-- Complete the URL -->
   
   <a href='http://students.engr.scu.edu/~jamedie/showBooks.php?show=true'>Show Books you have read</a>
   <br><br>
   <a href='http://students.engr.scu.edu/~jamedie/showBooks.php?howmany=true'>Show the no. of books you have read</a>
	 <br><br>
   <a href='http://students.engr.scu.edu/~jamedie/showBooks.php?bookdetails=true'>Show the info on the books you've read</a>
	 <br><br>

   <!-- Add a link here to call your new function, bookDetails -->
   
<?php

if (isset($_GET['show'])) {
    showBooks();
}
elseif (isset($_GET['howmany'])) {
    howManyBooks();
} elseif (isset($_GET['bookdetails'])){
		bookDetails();
}

function showBooksWithHighLights(){
	bookDetails();
}
function howManyBooks(){
	//connect to your database. Type in your username, password and the DB path
	$conn=oci_connect("jamedie", "Liveoak123", "//dbserver.engr.scu.edu/db11g");
	if(!$conn) {
	     print "<br> connection failed:";
        exit;
	}
	
	$query = oci_parse($conn, "SELECT bookcount from Dual");
	
	// Execute the query
	oci_execute($query);
	if (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
		echo "You have read <font color='blue;font-size:20px'> $row[0] </font></br>";
	}
}
function showBooks(){
	//connect to your database. Type in your username, password and the DB path
	$conn=oci_connect("jamedie", "Liveoak123", "//dbserver.engr.scu.edu/db11g");
	if(!$conn) {
	     print "<br> connection failed:";       
        exit;
	}		
	$query = oci_parse($conn, "SELECT * FROM Books_read");
	
	// Execute the query
	oci_execute($query);
	while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {		
		// We can use either numeric indexed starting at 0 
		// or the column name as an associative array index to access the colum value
		// Use the uppercase column names for the associative array indices		
		echo "<font color='black'> $row[0] </font></br>";
		echo "<font color='black'> $row[1] </font></br>";
	}
	OCILogoff($conn);	
}
// Complete the function below as described on the assignment.

function  bookDetails(){
	//shows the title, author, category and highlights of the books	
		$conn=oci_connect("jamedie", "Liveoak123", "//dbserver.engr.scu.edu/db11g");
		if (!$conn) {
			print "<br> connection failed:";
			exit;
		}
		$query = oci_parse ($conn, "SELECT * from books_read natural join Book_HighLights");

		oci_execute($query);
		while (($row = oci_fetch_array($query, OCI_BOTH)) != false) {
			// We can use either numeric indexed starting at 0
			// or the column name as an associative array index to access the colum value
			// Use the uppercase column names for the associative array indices
			echo "<font color='black'> Title: $row[0], Author: $row[1], category: $row[2], highlights: $row[4]</font></br>";

		}
		OCILogoff($conn);
}



?>
<!-- end PHP script -->
   </body>
</html>

