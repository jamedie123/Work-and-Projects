<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8"/>
      <title>Query Book details</title>
   </head>
   <body>
<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") {

     $salary = $_POST['salary'];

 
  $conn=oci_connect("jamedie", "Liveoak123", "//dbserver.engr.scu.edu/db11g");
  if (!$conn) {
        print "<br> connection failed:";
          exit;  }
  
  $query = oci_parse ($conn, "SELECT name from AlphaCoEmp where salary >= :salary and salary < :salary + 20000");
  oci_bind_by_name($query, ':salary', $salary);
  oci_execute($query);
  
  while (($row = oci_fetch_array($query, OCI_BOTH)) != false) { 
    echo "<font color='black'>$row[0]</font></br>";
  }
  OCILogoff($conn);
}
?>
</body>
</html>
