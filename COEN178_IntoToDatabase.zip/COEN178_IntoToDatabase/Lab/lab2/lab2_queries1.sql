
---PART 2
--a)
select CUSTID , FIRSTNAME  ||' '|| 	LASTNAME As FullName, CITY from Customer;
--b)
select CUSTID , FIRSTNAME  ||' '|| 	LASTNAME As FullName, CITY from Customer order by LASTNAME;
--c)
select SERVICEID, CUSTID, DAY from Schedule order by SERVICEID , CUSTID desc;
--d)
select SERVICEID from DeliveryService minus select SERVICEID from Schedule;
--e)
select distinct c.firstname||' '||c.lastname as Name from customer c, schedule s where day = 'm' and c.custid=s.custid; 
--f)
select distinct c.lastname from Customer c, schedule s where c.custid=s.custid; 
--g)
select max(SERVICEFEE) from DELIVERYSERVICE; 
--h)
select day, count(serviceid) from schedule group by day;
--i)
 Select A.custid, B.custid, A.city  from Customer A, Customer B 
 where A.city = B.city and A.custid != B.custid; 
--j)
 Select C.firstname from Customer C, DELIVERYSERVICE D, schedule S 
 where C.city = D.location and C.custid = S.custid  and S.serviceid = D.serviceid; 
--k)
select max(salary) As Highest_Salary  from staff_2010;
select min(salary) As Lowest_Salary  from staff_2010;
