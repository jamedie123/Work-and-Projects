--PART 3---

select * from L_EMP;
select * from L_DEPT;
--Exercise#1
--Approach#1
select EMPNAME from L_EMP, L_DEPT  where L_Dept.deptname='Testing' and L_EMP.deptid = L_Dept.deptid;

--Approach#2
select EMPNAME from L_EMP where L_EMP.deptid = (select deptid from L_DEPT where deptname = 'testing');
select EMPNAME from L_EMP where L_EMP.deptid = (select deptid from L_DEPT where deptname = 'Testing');

--Exercise#2
--Approach#1
select distinct deptname from L_DEPT 
LEFT JOIN L_EMP ON L_DEPT.deptid = L_EMP.deptid where L_EMP.deptid is null;

--Approach#2
select deptname from L_DEPT where L_DEPT.deptid not in (select deptid from L_EMP);