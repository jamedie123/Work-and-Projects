--Exercise#1
--Write a query to show the full names of employees with maximum salary.
--Approach 1: Complete the subquery below and run it.
 
--Select salary from Staff_2010
--where salary (Select salary from Staff_2010);

select distinct first || ' '|| last, salary from staff_2010
    where salary = (select max(salary) from staff_2010);

--Approach 2: Complete the subquery below and run it.
Select salary from Staff_2010 where salary in (Select max(salary) from Staff_2010);

select distinct first || ' '|| last, salary from Staff_2010 where salary in (Select max(salary) from Staff_2010);

--======================================================================================
--Exercise 2 (10 pts)
--Using the query below, find the last names of people with the same salary as “Zichal”.

Select distinct last, salary
from Staff_2010
where salary = (select distinct salary from Staff_2010 where last = 'Zichal');

--a)
Select distinct last, salary
from Staff_2010
where salary = (select distinct salary from Staff_2010 where upper(last) = upper('Zichal'));

---b)
Select distinct last, salary
from Staff_2010
where salary = (select distinct salary from Staff_2010 where upper(last) = upper('Young'));

Select distinct last, salary
from Staff_2010
where salary in (select distinct salary from Staff_2010 where upper(last) = upper('Young'));

--======================================================================================
--Exercise 3 (5 pts)
--Write and run a query to find the number of people with salaries greater than 100,000.
-- Note: the output should be like something given below (the count may vary for your table)
--SALARIES_100K_ABOVE
---------------------
-- 140

Select count(last) as SALARIES_100K_ABOVE
from Staff_2010
where salary > 100000;

--======================================================================================
--Exercise 4 (10 pts)
--Write and run a query to find the number of people with salaries greater than 100,000 and
--grouped by a salary number. 

Select salary, count(last) as SALARIES_100K_ABOVE
from Staff_2010 group by salary
having salary > 100000;

--======================================================================================
--Exercise 5 (15 pts)
--Write and run a query to find the number of people with salaries greater than 100,000, grouped
--by a salary number, where the no. of people in the group is >= 10. See the example output
--below:
-- SALARY SALARIES_100K_ABOVE
-- ---------- -------------------
-- 130500 27
-- 172200 23

Select salary, count(last) as SALARIES_100K_ABOVE
from Staff_2010 group by salary
having salary > 100000 and count(*) >=10;

--======================================================================================
--Exercise 6 (5 pts)
--Examine the query below. It uses regular expressions (regex) to show the last names where the
--same vowel repeats itself.
--SELECT last
--FROM Staff_2010
--WHERE REGEXP_LIKE (last, '([aeiou])\1', 'i');
--Examine the output. What is the option “i” for?  

-- i  specifies case-insensitive 

SELECT last FROM Staff_2010
WHERE REGEXP_LIKE (last, '([aeiou])\1', 'i');