--Exercise 7 (15 pts)
--In this query, we want to show the deptid and the number of employees in each dept. 
-- This information comes from L_EMP table. 
--Write the Select query to show deptid and count(*) from L_EMP. 
-- Make sure that you group by deptid. Name deptid column as deptno and the count(*) column as empcount . 
-- Show the results of query.

Select deptid as deptno, count(*)  empcont from L_EMP  group by deptid
--Or
Select deptid as deptno, count(empname)  empcount from L_EMP  group by deptid

--======================================================================================
--Exercise 8 (10 pts)
--In this query, we want to show the deptname (note the change from the previous exercise) and the
--number of employees in each dept. This information comes from both L_EMP and L_DEPT tables.
--To write this query, we will use the fact that a subquery can be given in the FROM clause.
--a) Use the query in exercise 7, as the subquery below. 
--This will go in to the from clause of the query below:

--Select deptno,deptname,empcount
--from (include your query here),L_DEPT
--where deptno = L_DEPT.deptid

Select deptno,L_DEPT.deptname,empcount
from (Select deptid as deptno, count(*) empcount from L_EMP group by deptid ),L_DEPT
where deptno = L_DEPT.deptid;

--b) Ascending ORDER

Select deptno,L_DEPT.deptname,empcount
from (Select deptid as deptno, count(*) empcount from L_EMP group by deptid ),L_DEPT
where deptno = L_DEPT.deptid order by empcount;
--======================================================================================
--Exercise 9 (10 pts)
--In this exercise, we will find the deptid of the department with maximum number of employees.
--Attempt 1: Try the query below. Will it work? No
Select deptid, max(count(*)) from L_EMP
Group by deptid;


--Attempt 2: Try the query below. Will it work?  No, I had to add MAX
Select deptid from L_EMP
Group by deptid
Having count(*) = (Select count(*) from L_EMP
Group by deptid);


--a) What is the problem with the above query? Fix the query in approach 2 and run it.
--I am getting the following error becasue the subquery returns more than 1 department
--ORA-01427: single-row subquery returns more than one row

Select deptid from L_EMP
Group by deptid
Having count(*) = (Select max(count(*)) from L_EMP
Group by deptid);

--b) Find the dept.name of the department with maximum number of employees.
-- So we need to add max(count(*)) in the subquery

Select L_DEPT.deptname from L_EMP, L_DEPT
where L_EMP.deptid = L_DEPT.deptid GROUP BY deptname
Having count(*) = (Select max(count(*)) from L_EMP Group by deptid);

--======================================================================================
--Exercise 10 (10 pts)
--Write a query, to show the employee and dept. information only where there are employees
--working in a dept. Include only those tuples that have a common deptid in both relations

--a) Run the query ( using natural join) below.
Select * from L_EMP NATURAL JOIN L_DEPT;

-- Show the output.
--b) The query (incomplete) query below accomplishes the same thing using cartesian product.
--Complete it and run to display the same output as shown by the query in a).

--Select  * from L_EMP, L_DEPT;

Select distinct * from L_EMP, L_DEPT where L_EMP.DEPTID = L_DEPT.DEPTID;