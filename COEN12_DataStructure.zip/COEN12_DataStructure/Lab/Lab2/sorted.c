/****************************************************************************************
Name:    Jacob Amedie 
Teacher: Professor Liu
COEN12:  Lab 2 -- sorted.c
Date :   10/11/15
Purpose: This file contains functions to implement a sorted array data structure using a set  ...
**********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>

#include "set.h"

struct set {
	int count;
	int length;
	char* *elts;
};

/*
 * Function: createSet  -- Runtime 0(1)
 * Description:	creates a pointer to a set that holds an array of strings, the number of elements in the array 
 *				and the length of the array 
 */
SET *createSet(int maxElts) {
    
	SET *sp; 
	sp = malloc(sizeof(SET));  /* Allcates space for structure... */
	assert(sp != NULL);         /* verify malloc ran properly */
	
	 //initialize the array of strings to hold unique words
	sp->elts = malloc(sizeof(char*)*maxElts);
	assert(sp->elts != NULL);    	/* verify that array was intialized properly*/
	sp->count = 0;
	sp->length = maxElts;
	
	return sp;
}

/*
 * Function:  destroySet  --  Runtime 0(n)
 * Description:	destroys the set by freeing the memory that the set holds 
 */
void destroySet(SET *sp) {
	
	assert(sp != NULL);
	int i;
	
	for(i = 0; i < sp->count; i++) 
    {
		free(sp->elts[i]);
	}
	
	free(sp->elts);
	free(sp);
	return;	
}

/*
 * Function: findElement   --  Runtime 0(log n)
 * Description:	function to search a SET for a specific elt using binary search.
 */
static int findElement(SET *sp, char *elt, bool *found){
    int lo, hi, mid, dif;
    lo = 0;
    hi = sp->count-1;
    
    while(lo<=hi){
        mid = (lo+hi)/2;
        dif = strcmp(elt, sp->elts[mid]);
        
        // if found == true it returns the index of the value
        // if found == false it returns where the value should go
        if(dif < 0)
            hi = mid -1;
        else if(dif > 0)
            lo = mid + 1;
        else{             
            *found = true;
            return mid;
        }
    }
    
    *found = false;
    return lo;
}

/*
 * Function: numElements   -- Runtime 0(1)
 * Description:	returns the number of elements in a set
 */
int numElements(SET *sp) {
	assert(sp != NULL);
	return sp->count;
}

/*
 * Function: hasElement   -- Runtime 0(log n)
 * Description:	uses findElement to return a boolean value for whether or not an element is in the set
 */
bool hasElement(SET *sp, char*elt) {
        assert(sp != NULL);
        /* if findElement sets *found to false, then elt is not in the set, return false, else return true*/
		bool f = true;
		int index;
		index = findElement(sp,elt, &f);
        if(f == false) {
            return false;
        }//end if
        else {
            return true;
        }
}

/*
 * Function: addElement   -- Runtime 0(n)
 * Description:	Add an element to the array if it doesn't already exist in the array
 */
bool addElement(SET *sp, char *elt){
    int i, index;
    bool found;
    assert(sp != NULL && elt != NULL);
     /* If the set does not contain elt, then add it to the set using strdup to allocate memory and then increment sp->count */
    index = findElement(sp, elt, &found);
    
    /* if *found == false, then elt is not in the set, so findElement will return lo, which is the position where elt needs to be added	*/
    if(found || sp->count == sp->length)
        return false;
        
    elt = strdup(elt);
    assert(elt != NULL);
    sp->count++;
    
    for(i = sp->count; i > index; i--){
        sp->elts[i] = sp->elts[i-1];
    }
    
    sp->elts[index] = elt;
    return true;
}

/*
 * Function: removeElement    -- Runtime O(n) + O(log n) = O(n)
 * Description:	removes an element from a set, returns true if element was removed
 */
bool removeElement(SET *sp, char *elt) {
	/* if elt can be found, then move the final element in the array to the index of elt, and free the final index */
	int index, i;
    bool found;
    assert(sp != NULL && elt != NULL);
    index = findElement(sp, elt, &found);
    if(!found) return false;
    free(sp->elts[index]);
    for(i = index; i < sp->count-1; i++)
        sp->elts[i] = sp->elts[i+1];
    sp->count--;
    return true;
}
