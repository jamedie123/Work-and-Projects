//Jacob Amedie	
//9-21-15
//
//count.c
//Monday Lab Section

#include<stdio.h>

# define MAX_WORD_LENGTH 30

int main(int argc, char * argv[])
{
	//Variable Declarations
	FILE* fp = NULL; 
	char word[MAX_WORD_LENGTH];
	int count = 0 ;
	
	// Opens text file to be read from	
	if ((fp = fopen(argv[1],"r")) == NULL )
	{
	   printf("File can't be opened");
           return -1;
	}
	
	// increment count once for each word gone over
	while( fscanf(fp, "%s", word ) != EOF )
	{
	   count ++;
	}

	// prints the total word count 
	printf("\n Total number of words in file is %d \n", count);
	return 0;
}
