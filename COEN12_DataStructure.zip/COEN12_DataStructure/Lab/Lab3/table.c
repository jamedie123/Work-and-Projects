/****************************************************************************************
Name:    Jacob Amedie 
Teacher: Professor Liu
COEN12:  Lab 2: unsorted.c
Date :   10/11/15
Purpose: This file contains functions to implement an unsorted array data structure using a set  ...
**********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <string.h>
#include "set.h"

#define EMPTY 0
#define FILLED 1
#define DELETED 2
struct set {
    int count;
    int length;
    char **elts;
	char *flags;
};

/*
 * Function: createSet  -- Runtime 0(1)
 * Description:	creates a pointer to a set that holds an array of strings, the number of elements in the array 
 *				and the length of the array 
 */
SET *createSet(int maxElts) {
    
    SET *sp; 
	sp = malloc(sizeof(SET));  /* Allcates space for structure... */
	assert(sp != NULL);         /* verify malloc ran properly */
	
	 //initialize the array of strings to hold unique words
    sp->elts = malloc(sizeof(char*)*maxElts); 
    assert(sp->elts != NULL);
	sp->count = 0;
    sp->length = maxElts;
	sp->flags = malloc(sizeof(char) *maxElts);
	assert(sp->flags != NULL);
	
    int i;
	for (i = 0; i < sp->length; i++) {
		sp->flags[i] = EMPTY;
	}
	
    return sp;
}

/*
 * Function:	destroySet  --  Runtime 0(n)
 * Description:	destroys the set by freeing the memory that the set holds 
 */
void destroySet(SET *sp) {
	
  assert(sp != NULL);
  int i;
	
  for(i = 0; i < sp->length; i++) {
     if (sp->flags[i] != DELETED) {
				free(sp->elts[i]);
		}
    }
    
   free(sp->elts);
   free(sp->flags);
   free(sp);
}

/*
 * Function: numElements   -- Runtime 0(1)
 * Description:	returns the number of elements in a set
 */
int numElements(SET *sp) {
	assert(sp != NULL);
	return sp->count;
}


/*
 * Function: hashString -- Runtime 0(n) - n is the strings length
 * Description: returns the value of the hash function for a given string
*/

 unsigned hashString(char *s) {
	unsigned hash = 0;
	while(*s != '\0')
		hash = 31 * hash + *s ++;
	return hash;
 } 

 /*
 * Function:    findElement
 * Description: traverses through the array using hashing to find the index of an element
 *              Best Case: O(1) -  Expected case: O(1) -	Worst case: O(n)
 */
static int findElement(SET *sp, char *elt, bool *found) {
	assert(sp != NULL);
	int index = (hashString(elt))%(sp->length);
	
	// If the set does not contain elt, found == false & return index
	if (sp->flags[index] == EMPTY) {
		*found = false;
		return index;
	}
	
	int firstDeleted = -1;
	
	// if index is not empty, then search if the element was inserted in the hash table
	while (sp->flags[index] != EMPTY) {
		if(strcmp(sp->elts[index], elt) == 0 && sp->flags[index] != DELETED) {
			*found = true;
			return index;
	}
	
    //record the first deleted entry found in order to reclaim it later (only want to find it once)
	if (sp->flags[index] == DELETED && firstDeleted == -1) {
			firstDeleted = index;
		}
	
    	index = (index + 1) % (sp->length);
	}
	
	/*
 	* If the while loop terminates, then it has found an empty slot, and that is where the element should be inserted, or the element cannot be found
	* Want to clear some of the deleted entries, so set index to the first deleted entry in the hash table	if a deleted entry was encountered
	*/
		
	*found = false;
	if (firstDeleted != -1) {
		index = firstDeleted;
	}
	return index;
}//end findElement

/*
 * Function:    hasElement -- Best case : O(1) - Worst case:  O(n) -	Expected case: O(1)
 * Description: uses findElement to return a boolean value for whether or not an element is in the set				
 */
 
bool hasElement(SET *sp, char*elt) {
        assert(sp != NULL);
        // if findElement sets found=false, then elt is not in set, return false, else true
		bool found;
		int index;
		index = findElement(sp,elt, &found);   
        if(found == false) {
            return false;
        }//end if
        else {
            return true;
        }
}

/*
 * Function:    addElement Best --  case: O(1) -- Expected Case: O(1) -- Worst case: O(n)
 * Description: Add an element to the array if it is not in the array            
 */

bool addElement(SET *sp, char *elt) {
	assert(sp->count < sp->length);
	bool found;
	// If sp->length == sp->count, then nothing more can be added (table is full)
	if (sp->length == sp->count) {
		return false;
	}
	int index = findElement(sp, elt, &found);
	//if findElement returns false, then elt is not a duplicate and can be added at the index
	if (found == false) {
		sp->elts[index] = strdup(elt);
		sp->flags[index] = FILLED;
		sp->count++;
		return true;
	}
	else {
		return false;
	}
}

/*
 * Function: removeElement  -- Best case: O(1)  - Expected case: O(1) - Worst case : O(n)
 * Description:	removes a given element from a set		
 */
bool removeElement(SET *sp, char *elt) {
        int index = 0;
		bool found;
		
        // if elt is found, then move the final element to the index of elt
		index = findElement(sp, elt, &found);
        
        if(found == true) {
			free(sp->elts[index]);
			sp->flags[index] = DELETED;
			sp->count--;
			return true;
        }
        else {
            return false;
        }
}
