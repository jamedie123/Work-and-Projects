/**********************************************************************************************
Name:    Jacob Amedie 
Teacher: Professor Liu
COEN12:  Lab 6: deque.cpp
Date :   12/6/15
Purpose: This file contains functions to implement the deque using a circular, 
         doubly-linked list with a sentinel or dummy node in C++
**********************************************************************************************/

#include <cassert>
#include "deque.h"
#define DUMMY head

class Node
{
	public:
	int data;
	class Node *next;
	class Node *prev;
};


/*
 * Function: createDeque  -- Runtime 0(1)
 * Description:	creates a new DEQUE with a dummy node
 */
Deque::Deque()
{
	count = 0;
	head = new Node;
	DUMMY->next = DUMMY;
	DUMMY->prev = DUMMY;
}

/*
 * Function: destroySet  -- Runtime: O(n)
 * Description: traverse through the linked list and free all of the memory that has been allocated
 */
Deque::~Deque()
{
	Node *p, *q;
	p = q = DUMMY->next;
	while (p != DUMMY)
	{
		q = p;
		p = p->next;
		delete q;
	}
	delete DUMMY;
}

/*
 * Function: numItems   -- Runtime:	O(1)
 * Description: return the number of items in the deque
 */
int Deque::size()
{
	return count;
}

/*
 * Function: addFirst -- Runtime: O(1)
 * Description: add the data into a node at the beginning of a given list.  Allocate memory for the node, and assign pointers...
 */
void Deque::addFirst(int x)
{
	Node *temp;
	temp = new Node;
	temp->data = x;
	temp->prev = DUMMY;
	temp->next = DUMMY->next;
	temp->next->prev = temp;
	DUMMY->next = temp;	
	count++;
}

/*
 * Function: addLast --  Runtime: O(1)
 * Description: add the data into a node at the end of a given list.  Allocates memory for the node and assigns pointers...
 */
void Deque::addLast(int x)
{
	Node *temp;
	temp = new Node;
	temp->data = x;
	temp->next = DUMMY;
	temp->prev = DUMMY->prev;
	DUMMY->prev->next = temp;
	DUMMY->prev = temp;
	count++;
}

/*
 * Function: removeFirst -- Runtime: O(1)
 * Description: returns the data of 1st node in the list, reassigns pointers to maitain list, and then delete the 1st node
 */
int Deque::removeFirst()
{
	assert (count != 0);

	int x;
	Node *temp, *np;
	temp = DUMMY;
	np = temp->next;
	temp->next = np->next;
	np->next->prev = temp;
	x = np->data; //save the data before deleting node
	delete np;
	count--;
	return x;
}

/*
 * Function: removeLast  --  Runtime:	O(1)
 * Description: returns the data of the last node in the list, reassigns pointers to maitain list, and then delete the last node
 */
int Deque::removeLast()
{
	assert (count != 0);

	int x;
	Node *temp, *np;
	temp = DUMMY;
	np = temp-> prev;
	np->prev->next = temp;
	temp->prev = np->prev;
	x = np->data; //save the data before deleting node
	delete np;
	count--;
	return x;
}

/*
 * Function: getFirst  -- Runtime: O(1)
 * Description: return the data from the first node in the list
 */
int Deque::getFirst()
{
	assert (count != 0);
	return DUMMY->next->data;
}

/*
 * Function: getLast  --  Runtime: O(1)
 * Description: returns the data from the last node
 */
int Deque::getLast()
{
	assert (count != 0);
	return DUMMY->prev->data;	
}
