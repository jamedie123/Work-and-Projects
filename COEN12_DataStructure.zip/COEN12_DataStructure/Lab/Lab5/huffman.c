/*******************************************************************************************
Name:    Jacob Amedie 
Teacher: Professor Liu
COEN12:  Lab 5: huffman.c
Date :   11/22/15
Purpose: This file contains functions to write a utility to perform compression on a file using Huffman coding
**********************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>

#include "tree.h"

#define SIZE 256
#define p(x) (((x)-1)/2)
#define l(x) (((x)*2)+1)
#define r(x) (((x)*2)+2)


// Functions Prototype
void count(FILE *file, int letterCount[]);
struct tree* insert(struct tree *newTree);
struct tree* buildTree();
void printHuffmanTree(struct tree *t);
struct tree *extractMinTree();
void storeLeaves (struct tree *t, struct tree*leaves[]);
void heapify(int i);

//Globals
struct tree *pQ[SIZE+1];
struct tree *leaves[SIZE+1];
int numElements;

int main (int argc, char *argv[]) 
{
	
    if (argc != 3) 
    {
		printf("Filenames missing, or too many filenames give!\n");
		return 1;
	}
	
    int i;
	numElements = 0;
	int letterCount[SIZE+1] = {};
	
    //set all the leaves Sto NULL
	for (i = 0; i < SIZE + 1; i++)
    {
		leaves[i] = NULL;
	}
	
    FILE *file = fopen(argv[1], "r");
	//count number of characters and occurances
	count(file, letterCount);
	fclose(file);
	
	// Create a tree for each character in the file, using the number of occurances of that character as the data for that tree
	//insert the EOF tree into the priority queue seperately 
	insert(leaves[256]);
	for (i = 0; i < SIZE+1; i++) 
    {
		if (letterCount[i] != 0)
        {
			struct tree *newTree = createTree(letterCount[i], NULL, NULL);
			leaves[i] = newTree;
			insert(newTree);
		}
	}
	
    // Building the Huffman tree
	struct tree* huffmanTree = buildTree();
	printf("%d \n", getData(huffmanTree));
	
	for (i = 0; i < SIZE+1; i++) 
    {
		if (leaves[i] != NULL) 
        {
			//print character and occurances
			if (isprint(i)) 
				printf("'%c': \t%d \t", i, getData(leaves[i]));
			else
				printf(" %o: \t%d \t", i, getData(leaves[i]));
			printHuffmanTree(leaves[i]);
			printf("\n");
		}
	}
	
    pack(argv[1], argv[2], leaves);
	destroyTree(huffmanTree);
	return 0;
}

/*
 *Funtion:	count
 *Description:	goes through the designated text file and counts the number of occurances of each unique character
 */

void count (FILE *file, int letterCount[]) {
	char c;
	//get all of the unique characters 
	while((c=getc(file)) != EOF) {
		letterCount[c]++;
	}//end while
	//create EOF tree and add it too leaves
	struct tree *t = createTree(0, NULL, NULL);
	leaves[256] = t;
}//end count

/*
 *Funtion:	insert
 *Description:	place the tree into the queue
 */
struct tree* insert(struct tree* newTree) {
// Insert new node at the end of queue
	int index = numElements;
	pQ[index] = newTree;
	int parentIndex = p(index);
	int data = getData(newTree);
	while (parentIndex > 0) 
    {
		if (getData(pQ[parentIndex]) > data)    //if the parent's data is greater than its child, swap the child and the parent
        {
			struct tree *temp = pQ[index];
			pQ[index] = pQ[parentIndex];
			pQ[parentIndex] = temp;
			index = parentIndex;
		}
		else
			break;
		parentIndex = p(index);
	}
	
	numElements++;
	return pQ[index];
}

/*
 *Funtion: buildTree
 *Description:	takes the priority queue and builds a huffman tree
 */
struct tree* buildTree() 
{
	 // Create a new tree with 2 min nodes once you find the 2 min values in queue
	 // Then se Left and Right nodes to min nodes
	printf("Heap initial: \n");
	int i;
	for (i = 0; i < numElements; i++) 
    {
		printf("%d ", getData(pQ[i]));
	}
	
	printf("\n");
	while (numElements > 1) 
    {
		int i;
		int index = 0;
		struct tree* min = extractMinTree();
        
        struct tree* secondMin = extractMinTree();  //find the second minimum 
		int combinedData = getData(min) + getData(secondMin);
		struct tree * combinedMin = createTree(combinedData, min, secondMin);
		
        insert(combinedMin);
		printf("Inserting: %d \n", getData(combinedMin));
		
        for( i = 0; i < numElements; i++)
        {
			printf("%d ", getData(pQ[i]));		
		}
		
		printf("\n \n");		
	}

	return pQ[0];  	// pQ[0] is the huffman tree
}

/*
 *Funtion:	printHuffmanTree
 *Description:	traverses tree to create andd print the leaf
 */
void printHuffmanTree(struct tree *t) 
{
	//If the node has no parent then it is the root, return
	if(getParent(t) == NULL) 
    {
		return;
	}
	
	// If  node is the left node of parent, print 0. And print 1 if it is the right node.
    if(getLeft(getParent(t)) == t)
			printf("0");
	if(getRight(getParent(t)) == t)
			printf("1");
	t = getParent(t);
	printHuffmanTree(t);
}

/*
 *Funtion:	extractMinTree
 *Description:	extract the first element from the priority queue and heapify the queue
 */
struct tree* extractMinTree() 
{
	if (numElements == 0)
		return;
	/*
	 * If the priority queue is kept in heap order, 
	 * then the first element will always be the smallest
	 */
	struct tree * extracted;
	extracted = pQ[0];
	// move the last element to the front
	pQ[0] = pQ[numElements-1];
	numElements--;  
	
    // Keep heap sorted after moving the last element to the front
	heapify(0);
	int i;
	printf("\n Extracting: %d \n", getData(extracted));
	
    for(i = 0; i < numElements; i++)
    {
		printf("%d ", getData(pQ[i]));		
	}
	printf("\n");
	return extracted;
}

/*
 *Funtion:	heapify
 *Description:	keeps the priority queue heap sorted, wi/ min in the first slot of the array
 */
void heapify(int i)
{
	int j;
	
	int l, r, smallest;
	l = l(i); // left node 
	r= r(i);  // right node
	
    // look for the min between the parent and subtrees
	if(l < numElements && getData(pQ[l]) < getData(pQ[i])) 
    {
		smallest = l;	
	}
	else {
		smallest = i;	
	}
	
    if (r< numElements && getData(pQ[r]) <= getData(pQ[smallest])) {
		smallest = r;	
	}
	
    //swap min child with parent to keep heap sorted
	if(smallest != i) 
    {
		struct tree *t = pQ[i];
		pQ[i] = pQ[smallest];
		pQ[smallest] = t;
		heapify(smallest); // Check if heap is sorted after moving 
	}
		
	return;
}
